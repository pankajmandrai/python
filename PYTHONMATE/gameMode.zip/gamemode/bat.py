import pygame
x= pygame.init()

#Creating window
gameWindow=pygame.display.set_mode((1200,500))
pygame.display.set_caption("my first game")

#game specific variable
exit_game =False
game_over =False

#Creating a game loop
while not exit_game:
   # pass
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            exit_game = True

        if event.type == pygame.KEYDOWN:
            if event.type ==pygame.K_RIGHT:
               print("you have pressed right arrow key")

pygame.quit()
quit()
