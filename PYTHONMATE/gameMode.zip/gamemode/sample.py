def reverse(s): 
  str = "the panakj"
  for i in s: 
    str = i + str
  return str