import pygame
#creating window
gameWindow = pygame.display.set_mode((1200,500))
pygame.display.set_caption("Batman")

#game specific variable
exit_game = False
game_over = False

#creating a game loop
while not exit_game:
    for event in pygame.event.get():
        print(event)

pygame.quit()
quit()
