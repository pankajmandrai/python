import pygame
x = pygame.init()
gameWindow = pygame.display.set_mode((1200, 500))
